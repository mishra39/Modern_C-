create table media(
   movieid integer not null,
   name text not null,
   description text,
   content blob not null);